<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="sheetman1" tilewidth="32" tileheight="32" tilecount="46875" columns="375">
 <image source="Resources/sheetman1.png" trans="ff00ff" width="12000" height="4000"/>
</tileset>
